package edu.cn.dao;

import edu.cn.pojo.Content;
import edu.cn.pojo.Person;
import edu.cn.pojo.Product;
import edu.cn.pojo.Trx;

import java.util.List;

public interface SaleDAO {
    public List<Product> getContent();

    public Person getUser(String userName);

    public int delContent(int id);

    public int insertPublic(Content content);

    public Product getProduct(int id);

    public Content getContenId(int id);

    public int updateConten(Content content);

    public Trx getTrx(int id);

    public int insertTrx(Trx trx);
}
