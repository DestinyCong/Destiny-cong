package edu.cn.pojo;

import java.math.BigInteger;
import java.sql.Blob;

public class Product extends Content {
    private boolean isBuy;
    private boolean isSell;
    private BigInteger buyPrice;
    private BigInteger buyTime;

    public Product() {
    }



    public Product(int id, BigInteger price, String title, String image, String summary, String detail, boolean isBuy, boolean isSell, BigInteger buyPrice, BigInteger buyTime) {
        super(id, price, title, image, summary, detail);
        this.isBuy = isBuy;
        this.isSell = isSell;
        this.buyPrice = buyPrice;
        this.buyTime = buyTime;
    }

    public boolean getIsBuy() {
        return isBuy;
    }

    public void setBuy(boolean buy) {
        isBuy = buy;
    }

    public boolean getIsSell() {
        return isSell;
    }

    public void setSell(boolean sell) {
        isSell = sell;
    }

    public BigInteger getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(BigInteger buyPrice) {
        this.buyPrice = buyPrice;
    }

    public BigInteger getBuyTime() {
        return buyTime;
    }

    public void setBuyTime(BigInteger buyTime) {
        this.buyTime = buyTime;
    }
}
