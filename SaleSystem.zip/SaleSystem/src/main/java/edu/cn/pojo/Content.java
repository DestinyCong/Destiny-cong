package edu.cn.pojo;

import java.math.BigInteger;

public class Content {
    private int id;
    private BigInteger price;
    private String title;
    private String image;
    private String summary;
    private String detail;

    public Content() {
    }

    public Content(int id, BigInteger price, String title, String image, String summary, String detail) {
        this.id = id;
        this.price = price;
        this.title = title;
        this.image = image;
        this.summary = summary;
        this.detail = detail;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BigInteger getPrice() {
        return price;
    }

    public void setPrice(BigInteger price) {
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }
}
