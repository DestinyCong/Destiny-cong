package edu.cn.controller;

import edu.cn.pojo.Content;
import edu.cn.service.SaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
public class PublicController {
    @Autowired
    private HttpServletRequest request;
    @Autowired
    private SaleService saleService;
    //发布
    @RequestMapping(value = "/public",method = RequestMethod.GET)
    public String ppublic(){
        return "public";
    }

    //提交发布
    @RequestMapping(value = "/publicSubmit")
    public String publicSubmit(Content content){
        try {
            Content product = saleService.insertPublic(content);
            request.setAttribute("product",product);
        }catch (Exception e){
            return "publicSubmit";
        }
        return "publicSubmit";
    }
}
