package edu.cn.controller;

import edu.cn.pojo.Person;
import edu.cn.pojo.Product;
import edu.cn.service.SaleService;
import edu.cn.util.AbstractJSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class LoginController {
    @Autowired
    private HttpSession session;
    @Autowired
    private HttpServletRequest request;
    @Autowired
    private SaleService saleService;
    @Autowired
    private AbstractJSON abstractJSON;

    //登录验证
    @RequestMapping(value = "/api/login", method = RequestMethod.POST)
    @ResponseBody
    public AbstractJSON login(String userName, String password) {
        try {
            Person person = saleService.getUser(userName);
            if (person.getUserName().equals(userName) && person.getPassword().equals(password)) {
                session.setAttribute("user", person);
                abstractJSON.setCode(200);
                abstractJSON.setResult(true);
            } else {
                abstractJSON.setCode(401);
                abstractJSON.setMessage("账户或密码错误");
                abstractJSON.setResult(false);
            }
        }catch (Exception e){
            abstractJSON.setCode(401);
            abstractJSON.setMessage("账户或密码错误");
            abstractJSON.setResult(false);
        }
        return abstractJSON;
    }

    //退出登录
    @RequestMapping(value = "/logout",method = RequestMethod.GET)
    public String logout() {
        Person user = (Person) session.getAttribute("user");
        if (session != null && user != null) {
            session.removeAttribute("user");
        }
        return "redirect:/";
    }
}
