package edu.cn.controller;

import edu.cn.pojo.Content;
import edu.cn.pojo.Person;
import edu.cn.pojo.Product;
import edu.cn.pojo.Trx;
import edu.cn.service.SaleService;
import edu.cn.util.AbstractJSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class SaleController {
    @Autowired
    private HttpSession session;
    @Autowired
    private HttpServletRequest request;
    @Autowired
    private SaleService saleService;
    @Autowired
    private AbstractJSON abstractJSON;
    @Autowired
    private Trx trx;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String index(Integer type, ModelMap modelMap) {
        Person user = (Person) session.getAttribute("user");
        if (null == type) {
            type = 0;
        }
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("type", type);
        modelMap.addAttribute("RequestParameters", map);
        List<Product> productList = saleService.getContens();
        session.setAttribute("user", user);
        request.setAttribute("type", type);
        request.setAttribute("productList", productList);
        return "index";
    }

    //跳转到登录页面
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String toLogin() {
        return "login";
    }

    //删除商品
    @RequestMapping(value = "/api/delete", method = RequestMethod.POST)
    @ResponseBody
    public AbstractJSON delectContent(int id) {
        if (saleService.delContent(id)) {
            abstractJSON.setCode(200);
            abstractJSON.setResult(true);
        } else {
            abstractJSON.setCode(401);
            abstractJSON.setMessage("商品不存在");
            abstractJSON.setResult(false);
        }
        return abstractJSON;
    }

    //查看
    @RequestMapping(value = "/show", method = RequestMethod.GET)
    public String show(int id) {
        Product product = saleService.getProduct(id);
        request.setAttribute("product", product);
        return "show";
    }


    @RequestMapping(value = "/account", method = RequestMethod.GET)
    public String account() {
        List<Product> productList = saleService.getContens();
        //只能去除一个
//        for (Product product : productList) {
//            System.out.println("11");
//            if (product.getIsBuy()==false){
//                productList.remove(product);
//                break;
//            }
//        }
        for (Iterator<Product> iterator = productList.iterator(); iterator.hasNext(); ) {
            Product product = iterator.next();
            if (product.getIsBuy() == false) {//未购买内容删除
                iterator.remove();
            }
        }
        request.setAttribute("buyList", productList);
        return "account";
    }

    //购买
    @RequestMapping(value = "/api/buy",method = RequestMethod.POST)
    @ResponseBody
    public AbstractJSON buy(int id) {
        Person user = (Person) session.getAttribute("user");
        Content content = saleService.getContenId(id);
        trx.setContentId(id);
        trx.setPersonId(user.getId());
        trx.setPrice(content.getPrice());
        Date date = new Date();
        BigInteger time = BigInteger.valueOf(date.getTime());
        trx.setTime(time);
        if (saleService.insertTrx(trx)){
            abstractJSON.setCode(200);
            abstractJSON.setResult(true);
        }else {
            abstractJSON.setCode(401);
            abstractJSON.setMessage("其他错误");
        }
        return abstractJSON;
    }
}
