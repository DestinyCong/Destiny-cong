package edu.cn.controller;

import edu.cn.pojo.Content;
import edu.cn.service.SaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
public class EditController {
    @Autowired
    private HttpServletRequest request;
    @Autowired
    private SaleService saleService;

    //编辑
    @RequestMapping(value = "/edit")
    public String edit(int id) {
        Content product = saleService.getContenId(id);
        request.setAttribute("product", product);
        return "edit";
    }

    //编辑提交
    @RequestMapping(value = "/editSubmit", method = RequestMethod.POST)
    public String editSubmit(Content content) {
        Content product = null;
        if (saleService.updateConten(content)){
            product = content;
        }
        request.setAttribute("product",product);
        return "editSubmit";
    }
}
