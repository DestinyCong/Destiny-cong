package edu.cn.service.impl;

import edu.cn.dao.SaleDAO;
import edu.cn.pojo.Content;
import edu.cn.pojo.Person;
import edu.cn.pojo.Product;
import edu.cn.pojo.Trx;
import edu.cn.service.SaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SaleServiceImpl implements SaleService {

    @Autowired
    private SaleDAO saleDAO;

    public List<Product> getContens() {
        List<Product> productList = saleDAO.getContent();
        for (Product product:productList){
            setProductInfo(product);
        }
        return productList;
    }

    public Person getUser(String username) {
        return saleDAO.getUser(username);
    }

    public boolean delContent(int id) {
        int i = saleDAO.delContent(id);
        if (i != -1) {
            return true;
        }
        return false;
    }

    public Content insertPublic(Content content) {
        int i = saleDAO.insertPublic(content);
        return content;
    }

    public Product getProduct(int id) {
        return saleDAO.getProduct(id);
    }

    public Content getContenId(int id) {
        return saleDAO.getContenId(id);
    }

    public Boolean updateConten(Content content) {
        int i = saleDAO.updateConten(content);
        if (i != -1) {
            return true;
        }
        return false;
    }

    public Boolean insertTrx(Trx trx) {
        int i = saleDAO.insertTrx(trx);
        if (i!=-1){
            return true;
        }
        return false;
    }


    public void setProductInfo(Product product) {
        try {
            Trx trx = saleDAO.getTrx(product.getId());
            product.setBuy(true);
            product.setSell(true);
            product.setBuyPrice(trx.getPrice());
            product.setBuyTime(trx.getTime());
        }catch (Exception e){
            product.setBuy(false);
            product.setSell(false);
        }
    }
}
