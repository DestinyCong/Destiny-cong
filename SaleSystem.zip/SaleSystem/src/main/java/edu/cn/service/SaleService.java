package edu.cn.service;

import edu.cn.pojo.Content;
import edu.cn.pojo.Person;
import edu.cn.pojo.Product;
import edu.cn.pojo.Trx;

import java.util.List;

public interface SaleService {
    public List<Product> getContens();

    public Person getUser(String userName);

    public boolean delContent(int id);

    public Content insertPublic(Content content);

    public Product getProduct(int id);

    public Content getContenId(int id);

    public Boolean updateConten(Content content);

    public Boolean insertTrx(Trx trx);
}
