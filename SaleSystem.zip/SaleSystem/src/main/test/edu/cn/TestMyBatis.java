package edu.cn;

import edu.cn.pojo.Content;
import edu.cn.pojo.Product;
import edu.cn.service.SaleService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/spring-mvc.xml")
public class TestMyBatis {

    @Autowired
    private SaleService saleService;

    @Test
    public void test(){
        List<Product> contents = saleService.getContens();
        for (Content content:contents){
            System.out.println(content);
        }
    }
}
